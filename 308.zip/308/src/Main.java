public class Main {

    public static void main(String[] args) {
        System.out.println(multiply(3,4));
    }

    public static int multiply(int a, int b) {
        int c = a * b;
        return c;
    }
}
